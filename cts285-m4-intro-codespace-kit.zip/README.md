# CTS-285 Module 4 intro — Codespace kit

A 20-minute lecture deck, a live-demo codebase, a 5-minute exercise, and a two-segment bonus assignment for students. Everything runs in one Codespace.

The lesson in one line: **we are back in Python. The systems analysis is the input. The code tests the design.**

## Contents

| Path | Purpose |
|---|---|
| `slides/index.html` | The deck. 22 slides, motion, speaker notes. No build step. |
| `app.py` | Text interface layer. The only file that calls `input()` and `print()`. |
| `dataman/logic.py` | Business-logic layer. The two-attempt rule and the 10-problem limit. |
| `dataman/store.py` | Stubbed data layer. `MemoryStore` and `JsonFileStore`. |
| `tests/test_logic.py` | 9 tests. They import the library only. |
| `exercise/` | Student exercise. One test fails on purpose. |
| `instructor/solution/` | Exercise answer. **Delete this folder before students see the repo.** |
| `.devcontainer/` | Python 3.12, pytest, and the slide server on port 8000. |
| `NOTES.md` | Student answers for the bonus. Parts tagged `[S1]` and `[S2]`. |
| `check.py`, `checks/originals.json` | Checkpoint check for the bonus. `python check.py 1` or `2`. |
| `student/` | Student-only README and devcontainer (no slides, no port 8000). |
| `pytest.ini` | Limits plain `pytest` to `tests/`, so the failing exercise does not run by default. |

## Set up (once)

Do not unzip on Windows and drag the folder into GitHub. The browser upload skips hidden folders such as `.devcontainer`. Upload the zip itself and unzip in the Codespace.

1. On GitHub, open the empty repository. Choose **Add file → Upload files**. Drag in `cts285-m4-intro-codespace-kit.zip`. Commit to `main`.
2. Choose **Code → Codespaces → Create codespace on main**.
3. In the Codespace terminal, run:
   ```sh
   unzip -o cts285-m4-intro-codespace-kit.zip
   git rm -q cts285-m4-intro-codespace-kit.zip
   git add -A && git commit -m "Add Module 4 intro kit" && git push
   ```
   If `unzip` is missing, use `python3 -m zipfile -e cts285-m4-intro-codespace-kit.zip .` and then `git rm` as above.
4. Rebuild the container so it reads `.devcontainer`: press `F1`, run **Codespaces: Rebuild Container**. The Codespace reloads in about a minute. It installs pytest and serves the deck on port 8000.
5. Check it: `pytest -q` shows 9 passed. The deck opens from the Ports tab (port 8000, "Open in Browser"). Use a full browser tab for the deck.
6. For the class: deck in one tab, terminal in another. Switch at slide 11.

If you skip the rebuild: run `pip install -r requirements.txt`, then `python -m http.server 8000 --directory slides`. Open port 8000 from the Ports tab.

Before students use the repo: delete the `instructor/` folder and commit.

## Bonus assignment: student template

The Canvas page is `m4-bonus-three-layers.html`. It sends students to a GitHub template repository. Build that repository from the second zip, `cts285-bonus-student-template.zip`. It has no `instructor/` and no `slides/`.

1. Create a new empty repository. Upload `cts285-bonus-student-template.zip`. Unzip it in a Codespace (same steps as Set up). Commit and push.
2. In the repository, open **Settings** and turn on **Template repository**.
3. Put the repository URL into the Canvas page. The one pending link is `bonus-template-repo`. See `PLACEHOLDERS.md`.
4. Keep `instructor/solution/` only in the full kit. Students never get it.

How a student works:

| Segment | Steps (min) | Ends with |
|---|---|---|
| 1 | Start 5, predict and find 10, run it 10, change the interface 10, push and check 5 | `python check.py 1` |
| 2 | Restart 3, add a rule 12, break it 10, swap the data 8, reflect, push, check 7 | `python check.py 2` |

Each segment is 40 minutes of steps and 5 minutes of buffer. The times are planned, not measured. Time the first class and edit the page.

What the check proves: tests pass, tests unchanged (hash), the library has no `input()` or `print()`, `app.py` changed, `NOTES.md` has no TODO for that segment, and the work is committed and pushed. Segment 2 also checks that the library is restored, the exercise tests pass, `default="json"` is set, and the Reflection has at least 25 words.

What the check does not prove: that the answers in `NOTES.md` are good. You read those.

If you change `tests/test_logic.py`, `app.py`, `dataman/logic.py`, `dataman/store.py`, or `exercise/test_bank.py`, regenerate `checks/originals.json`. The check compares file hashes to it.

## Deck keys

| Key | Action |
|---|---|
| → / Space / click | Next step |
| ← / click left edge | Back one step |
| N | Speaker notes (also on screen) |
| T | Clock with planned pace. `0` resets it. |
| C | Calm mode. Turns off motion. It is on by itself if the computer asks for reduced motion. |
| F | Full screen |
| Home / End | First / last slide |
| `#12` in the address | Jump to slide 12 |

## Run sheet

Planned pace. It has not been rehearsed. Time it on your first run.

| Slides | Topic | Min |
|---|---|---|
| 1–3 | Title, where we are, the question changes | 2.5 |
| 4 | **Back in code** (the main message) | 1.5 |
| 5–6 | Design loop, choose the lightest evidence | 2 |
| 7–8 | Sequence view, class view | 2.25 |
| 9 | Predict: where does the attempt count live? | 1 |
| 10–11 | Three layers, CLI + library shape | 2 |
| 12–15 | Four live demos in the Codespace | 5 |
| 17 | Bridge to Module 5 | 0.75 |
| 18–20 | Module path, GitHub trail, prototype minimum | 2.25 |
| 21–22 | Do now, close | 0.75 |
| | **Total** | **about 20** |
| 16 | Optional exercise | +5 |

## Demo commands

```sh
python app.py                      # Demo 1. practice -> 55 -> 54 -> report
pytest -q                          # Demo 2. 9 passed, no interface
python app.py --store json         # Demo 3. practice -> 55 -> Ctrl-C -> run again -> "Try 2"
python app.py                      # Demo 4. bank -> P1 ... P10, then P11 is refused
pytest exercise -q                 # Exercise. 1 failed until the rule is added
```

Delete `dataman_store.json` before the next class. It holds Demo 3 state.

## Design choices worth knowing

- **Attempt count is derived from the store**, not held in a variable. That is why Demo 3 resumes at try 2.
- **The deck does not give the lab answers.** Slide 9 asks the question and stops. The Answer Flow Lab and Memory Bank Lab (Module 4, pages 5–6) are built for students to find the consequences themselves. Demos 2 and 4 show the principle in code only.
- **Examples use DataMan content already in the binder:** 7 × 8, two attempts then reveal, three outcomes a curator must tell apart, 10-problem Memory Bank limit, and the sequence and class views from M4.1.

## Open flags — your call

1. **Kayfabe approval.** Slides 1 and 22 carry a SHODANN line. Slide 4 carries an "Instructor, out of character" margin. The deck is instructor-delivered. The 2026-09-16 decision requires item-by-item approval if you post it to Canvas.
2. **Verdict words differ in the binder.** The Module 4 overview names four verdicts: Ready, Revise, Split, Blocked. The Design Studio page lists six options: proceed, revise, split, gather more evidence, block/return for clarification, defer. Slide 19 shows the four. The one-line meaning under each is my paraphrase. Reconcile the pages or tell me which set to use.
3. **A graded item may be missing.** The Design Studio page says students will turn Studio evidence into a "formal Design Investigation Application." The binder's Module 4 list has no such item (item 9 is the prototype). The deck does not mention it.
4. **Interface layer wording.** The binder says "text interface layer" now and Flask in Module 5. The deck says "interface" and shows Flask arriving. It does not say GUI.
5. **RED clearance and the Copilot kit are not in the deck.** The kit draft is unrun, and the DECISIONS entry is not confirmed. Say where you want the RED hand-off and I will add one slide.
6. **Not tested in a live Codespace.** The tests, the CLI, and the deck were run here. The devcontainer file was not. Fonts load from Google Fonts. Without internet the deck falls back to system fonts.
7. **Slide 5 example row** (the DataMan question at each loop step) is mine. It is labeled illustrative on the slide.
8. **Bonus: points, due date, and where students submit the URL are not set.** The Canvas page says "Your instructor tells you where to submit its web address." Replace that when you decide. Canvas shows points and dates, so the page does not.
9. **Bonus: AI-use rules are not stated.** The page says nothing about using an AI assistant on `NOTES.md`. Add a line if you want one.
10. **Bonus: where it sits in the course is not assumed.** The page calls it "Module 4 · Bonus (beta)". Change the banner kicker if it belongs elsewhere.
11. **Bonus: grader access.** Students create the repository from the template. If it is private, you cannot read it unless they share it. The page says "Use the same sharing setting as your CTS-285 repository." Check that this works for you.
12. **Bonus: the gold hex `#E3B23C` is still an estimate.** Confirm the official FTCC value.
